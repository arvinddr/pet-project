import Alert from './Alert'

export type { AlertProps } from './Alert'
export { Alert }
export default Alert
