import SidePanel from './SidePanel'

export default SidePanel
