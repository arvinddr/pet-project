```jsx
import Alert from '@/components/ui/Alert'

const Basic = () => {
    return (
        <div>
            <Alert>
                Additional description and information about copywriting.
            </Alert>
        </div>
    )
}

export default Basic
```
