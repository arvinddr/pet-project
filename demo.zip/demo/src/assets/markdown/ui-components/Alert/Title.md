```jsx
import Alert from '@/components/ui/Alert'

const Title = () => {
    return (
        <div>
            <Alert showIcon type="danger" title="Error!">
                Additional description and information about copywriting.
            </Alert>
        </div>
    )
}

export default Title
```
