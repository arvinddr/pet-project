```jsx
import Upload from '@/components/ui/Upload'

const DragAndDrop = () => {
    return (
        <div>
            <Upload draggable />
        </div>
    )
}

export default DragAndDrop
```
