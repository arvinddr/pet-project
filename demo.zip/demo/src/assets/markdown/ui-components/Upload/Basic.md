```jsx
import Upload from '@/components/ui/Upload'

const Basic = () => {
    return (
        <div>
            <Upload />
        </div>
    )
}

export default Basic
```
