```jsx
import Skeleton from '@/components/ui/Skeleton'

const Animation = () => {
    return <Skeleton animation={false} />
}

export default Animation
```
