```jsx
import TimeInput from '@/components/ui/TimeInput'

const Invalid = () => {
    return <TimeInput invalid />
}

export default Invalid
```
