```jsx
import TimeInput from '@/components/ui/TimeInput'

const Basic = () => {
    return <TimeInput />
}

export default Basic
```
