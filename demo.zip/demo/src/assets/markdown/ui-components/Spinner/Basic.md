```jsx
import Spinner from '@/components/ui/Spinner'

const Basic = () => {
    return (
        <div>
            <Spinner />
        </div>
    )
}

export default Basic
```
