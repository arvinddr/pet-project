```jsx
import Input from '@/components/ui/Input'

const Disabled = () => {
    return (
        <div>
            <Input placeholder="Disabled Input" disabled />
        </div>
    )
}

export default Disabled
```
