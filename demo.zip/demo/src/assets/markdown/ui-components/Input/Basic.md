```jsx
import Input from '@/components/ui/Input'

const Basic = () => {
    return (
        <div>
            <Input placeholder="Basic usage" />
        </div>
    )
}

export default Basic
```
