```jsx
import DatePicker from '@/components/ui/DatePicker'

const { DateTimepicker } = DatePicker

const DateTimePicker = () => {
    return <DateTimepicker placeholder="Pick date & time" />
}

export default DateTimePicker
```
