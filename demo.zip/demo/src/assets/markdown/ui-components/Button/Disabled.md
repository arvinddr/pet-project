```jsx
import Button from '@/components/ui/Button'

const Disabled = () => {
    return (
        <div>
            <Button disabled>Default</Button>
        </div>
    )
}

export default Disabled
```
