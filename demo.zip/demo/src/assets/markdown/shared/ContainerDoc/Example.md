```jsx
import Container from '@/components/shared/Container'

const Example = () => {
    return <Container>Content</Container>
}

export default Example
```
