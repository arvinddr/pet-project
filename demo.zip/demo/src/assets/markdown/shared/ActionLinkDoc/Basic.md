```jsx
import ActionLink from '@/components/shared/ActionLink'

const Basic = () => {
    return (
        <ActionLink to="/docs/documentation/introduction">Navigate</ActionLink>
    )
}

export default Basic
```
