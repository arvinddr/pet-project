export { default as DriversLicenseSvg } from './DriversLicenseSvg'
export { default as NationalIdSvg } from './NationalIdSvg'
export { default as PassportSvg } from './PassportSvg'
